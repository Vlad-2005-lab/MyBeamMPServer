      singleton Material(_1102_paint)
{
mapTo = "urus_main";
diffuseMap[0] = "vehicles/common/null.dds";
diffuseColor[0] = "1 1 1 1";
diffuseColor[1] = "0.1 0.1 0.1 0.5";
specularPower[0] = "16";
specularPower[1] = "16";
useAnisotropic[0] = "1";
useAnisotropic[1] = "1";
castShadows = "1";
translucent = "1";
translucentBlendOp = "None";
alphaTest = "0";
alphaRef = "0";
dynamicCubemap = true;
instanceDiffuse[2] = true;
materialTag0 = "beamng";
materialTag1 = "vehicle";
colorMap[0] = "vehicles/common/null.dds";
colorMap[1] = "vehicles/urus.png";
colorMap[2] = "vehicles/urus/urus_c.dds";
doubleSided = "0";
};

singleton Material(etk800_runninglight)
{
   mapTo = "etk800_runninglight";
   diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/urus/TXT/lights_on.png";
   diffuseMap[1] = "vehicles/urus/TXT/lights_on.png";
   materialTag0 = "Miscellaneous";
};

singleton Material(windows)
{
mapTo = "windows";
diffuseMap[0] = "window.png";
diffuseColor[0] = "1 1 1 0.1";
translucentBlendOp = "None";
alphaTest = "1";
alphaRef = "0";
cubemap = "BNG_Sky_02_cubemap";
beamngDiffuseColorSlot = 1;
doubleSided = "1";
};

singleton Material(black)
{
mapTo = "black";
diffuseMap[0] = "black.png";
diffuseColor[0] = "1 1 1 0.1";
translucentBlendOp = "None";
alphaTest = "1";
alphaRef = "0";
cubemap = "BNG_Sky_02_cubemap";
beamngDiffuseColorSlot = 1;
doubleSided = "1";
};

singleton Material(rear_lights)
{
mapTo = "rear_lights";
diffuseMap[0] = "Rear.png";
diffuseColor[0] = "1 1 1 0.1";
translucentBlendOp = "None";
alphaTest = "1";
alphaRef = "0";
cubemap = "BNG_Sky_02_cubemap";
beamngDiffuseColorSlot = 1;
doubleSided = "1";
};

singleton Material(RSglass)
{
    mapTo = "glass";
    reflectivityMap[0] = "vehicles/urus/glass_base.dds";
    diffuseMap[0] = "vehicles/urus/glass_base_2.dds";
    opacityMap[0] = "vehicles/urus/glass_base.dds";
    diffuseMap[1] = "vehicles/urus/glass_base_2.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/common/null_n.dds";
    diffuseColor[1] = "0.5 0.5 0.5 0.75";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(plastika)
{
mapTo = "plastika";
materialTag0 = "plastika"; materialTag1 = "vehicle";
colorMap[0] = "grey.jpg";
pixelSpecular[0] = "1";
diffuseColor[0] = "0.988235 0.996078 0.988235 0.396";
instanceDiffuse[0] = 0;
dynamicCubemap = false;
};

singleton Material(colorbody)
{
   mapTo = "colorbody";
   diffuseMap[0] = "vehicles/common/null.dds";
   specularMap[0] = "vehicles/common/null.dds";
   diffuseMap[1] = "vehicles/common/null.dds";
   specularMap[1] = "vehicles/common/null.dds";
   diffuseColor[0] = "0.8 0.8 0.8 1";
   diffuseColor[1] = "0.9 0.9 0.9 0.6";
   specularPower[0] = "16";
   specularPower[1] = "16";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   castShadows = "1";
   translucent = "1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   beamngDiffuseColorSlot = 1;
   doubleSided = "1";
   dynamicCubemap = true;
   instanceDiffuse[1] = true;
};

singleton Material(etk800_glass_dmg)
{
   mapTo = "etk800_glass_dmg";
    reflectivityMap[0] = "vehicles/common/glass_base.dds";
    diffuseMap[0] = "vehicles/common/glass_base_2.dds";
    opacityMap[0] = "vehicles/common/glass_base.dds";
    diffuseMap[1] = "vehicles/urus/cracks.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/urus/cracks_n.dds";
    normalMap[1] = "vehicles/urus/cracks_n.dds";
    diffuseColor[1] = "0.5 0.5 0.5 0.75";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(etk800_windshield_dmg)
{
   mapTo = "etk800_windshield_dmg";
    reflectivityMap[0] = "vehicles/common/glass_base.dds";
    diffuseMap[0] = "vehicles/common/glass_base_2.dds";
    opacityMap[0] = "vehicles/common/glass_base.dds";
    diffuseMap[1] = "vehicles/urus/cracks.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/urus/cracks_n.dds";
    normalMap[1] = "vehicles/urus/cracks_n.dds";
    diffuseColor[1] = "0.5 0.5 0.5 0.75";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(etk800_runninglight_on)
{
   mapTo = "etk800_runninglight_on";
   specular[0] = "0.996078491 0.996078491 0.996078491 1";
   glow[0] = "1";
   glow[1] = "1";
   emissive[0] = "1";
   emissive[1] = "1";
   translucentBlendOp = "None";
   colorMap[0] = "vehicles/urus/TXT/lights_on.png";
   specular[1] = "0.988235354 0.988235354 0.988235354 0.00800000038";
   pixelSpecular[0] = "1";
   pixelSpecular[1] = "1";
   materialTag0 = "Miscellaneous";
};

singleton Material(frontoff)
{
   mapTo = "frontoff";
   diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/urus/TXT/f_light.png";
   diffuseMap[1] = "vehicles/urus/TXT/f_light.png";
   materialTag0 = "Miscellaneous";
};

singleton Material(etk800_lights_on)
{
   mapTo = "etk800_lights_on";
   specular[0] = "0.996078491 0.996078491 0.996078491 1";
   glow[0] = "1";
   glow[1] = "1";
   emissive[0] = "1";
   emissive[1] = "1";
   translucentBlendOp = "None";
   colorMap[0] = "vehicles/urus/TXT/lights_on.png";
   specular[1] = "0.988235354 0.988235354 0.988235354 0.00800000038";
   pixelSpecular[0] = "1";
   pixelSpecular[1] = "1";
   materialTag0 = "Miscellaneous";
};

singleton Material(endoff)
{
   mapTo = "endoff";
   diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/urus/TXT/RR.png";
   diffuseMap[1] = "vehicles/urus/TXT/RR.png";
   materialTag0 = "Miscellaneous";
};

singleton Material(rlig)
{
   mapTo = "rlig";
   specular[0] = "0.9 0.9 0.9 1";
   translucentBlendOp = "None";
   diffuseColor[0] = "1 0 0.0352941193 0.00800000038";
   diffuseColor[1] = "1 0 0.0352941193 0.00800000038";
   colorMap[0] = "vehicles/urus/TXT/red.png";
   glow[0] = "1";
   glow[1] = "1";
   emissive[0] = "1";
   emissive[1] = "1";
   materialTag0 = "beamng";
   materialTag2 = "Industrial";
   materialTag1 = "vehicle";
};

singleton Material(etk800_taillight)
{
   mapTo = "etk800_taillight";
   specular[0] = "0.9 0.9 0.9 1";
   translucentBlendOp = "None";
   diffuseColor[0] = "1 0 0.0352941193 0.00800000038";
   diffuseColor[1] = "1 0 0.0352941193 0.00800000038";
   colorMap[0] = "vehicles/urus/TXT/red.png";
   glow[0] = "1";
   glow[1] = "1";
   emissive[0] = "1";
   emissive[1] = "1";
   materialTag0 = "beamng";
   materialTag2 = "Industrial";
   materialTag1 = "vehicle";
};