singleton Material(Carbon)
{
    mapTo = "Carbon";
    diffuseMap[0] = "vehicles/panamera/carbon.tga";
    diffuseMap[1] = "vehicles/panamera/carbon.tga";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(svet)
{
    mapTo = "svet";
    diffuseMap[0] = "vehicles/panamera/5.png";
    diffuseMap[1] = "vehicles/panamera/5.png";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(spoiler)
{
    mapTo = "spoiler";
    diffuseMap[0] = "vehicles/bentleybentayga/2.png";
    diffuseMap[1] = "vehicles/bentleybentayga/2.png";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(niz)
{
    mapTo = "niz";
    diffuseMap[0] = "vehicles/panamera/2.png";
    diffuseMap[1] = "vehicles/panamera/2.png";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(puzo)
{
    mapTo = "puzo";
    diffuseMap[0] = "vehicles/panamera/2.png";
    diffuseMap[1] = "vehicles/panamera/2.png";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(glass)
{
   mapTo = "glass";
   diffuseColor[0] = "0.4 0.4 0.4 1";
   specularPower[0] = "300";
   translucentBlendOp = "Add";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   doubleSided = "1";
   castShadows = "0";
   translucent = "1";
   translucentZWrite = "1";
   alphaTest = "1";
   dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
};

singleton Material(glassfara)
{
   mapTo = "glassfara";
   diffuseColor[0] = "0.4 0.4 0.4 1";
   specularPower[0] = "300";
   translucentBlendOp = "Add";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   doubleSided = "1";
   castShadows = "0";
   translucent = "1";
   translucentZWrite = "1";
   alphaTest = "1";
   dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
};

singleton Material(glassfarazad)
{
   mapTo = "glassfarazad";
   diffuseColor[0] = "0.4 0.4 0.4 1";
   specularPower[0] = "300";
   translucentBlendOp = "Add";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   doubleSided = "1";
   castShadows = "0";
   translucent = "1";
   translucentZWrite = "1";
   alphaTest = "1";
   dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
};

singleton Material(window)
{
   mapTo = "window";
   diffuseColor[0] = "0.4 0.4 0.4 1";
   specularPower[0] = "300";
   translucentBlendOp = "Add";
   pixelSpecular[0] = "1";
   useAnisotropic[0] = "1";
   doubleSided = "1";
   castShadows = "0";
   translucent = "1";
   translucentZWrite = "1";
   alphaTest = "1";
   dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
};

singleton Material(vih)
{
   mapTo = "vih";
   diffuseMap[0] = "vehicles/bentleybentayga/1.png";
   diffuseColor[0] = "1 1 1 0.1";
   specularPower[0] = "106";
   specularPower[1] = "106";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = true;
   beamngDiffuseColorSlot = 1;
   doubleSided = "1";
};

singleton Material(red)
{
   mapTo = "red";

    diffuseMap[0] = "vehicles/bentleybentayga/3.png";
    diffuseMap[1] = "vehicles/bentleybentayga/3.png";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(interiorknopki)
{
    mapTo = "interiorknopki";
    diffuseMap[0] = "vehicles/bentleybentayga/interior.png";
    diffuseMap[1] = "vehicles/bentleybentayga/interior.png";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(badge)
{
    mapTo = "badge";
    diffuseMap[0] = "vehicles/bentleybentayga/2.png";
    diffuseMap[1] = "vehicles/bentleybentayga/2.png";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(lightper)
{
    mapTo = "lightper";
    diffuseMap[0] = "vehicles/bentleybentayga/4.png";
    specularMap[0] = "vehicles/bentleybentayga/4.png";
    diffuseMap[1] = "vehicles/bentleybentayga/4.png";
    specularMap[1] = "vehicles/bentleybentayga/4.png";
    diffuseColor[0] = "0.8 0.8 0.8 1";
    diffuseColor[1] = "0.9 0.9 0.9 0.6";
    specularPower[0] = "0";
    specularPower[1] = "0";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "1";
    alphaRef = "0";
    beamngDiffuseColorSlot = 1;
    doubleSided = "1";
    dynamicCubemap = true;
};

singleton Material(zadlight)
{
    mapTo = "zadlight";
diffuseMap[0] = "vehicles/bentleybentayga/3.png";
    diffuseMap[1] = "vehicles/bentleybentayga/3.png";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(inter)
{
    mapTo = "inter";
diffuseMap[0] = "vehicles/bentleybentayga/4.png";
    diffuseMap[1] = "vehicles/bentleybentayga/4.png";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(intersid)
{
    mapTo = "intersid";
diffuseMap[0] = "vehicles/bentleybentayga/2.png";
    diffuseMap[1] = "vehicles/bentleybentayga/2.png";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(grille)
{
    mapTo = "grille";
diffuseMap[0] = "vehicles/bentleybentayga/2.png";
    diffuseMap[1] = "vehicles/bentleybentayga/2.png";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(rad)
{
    mapTo = "rad";
diffuseMap[0] = "vehicles/bentleybentayga/2.png";
    diffuseMap[1] = "vehicles/bentleybentayga/2.png";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(chersalon)
{
    mapTo = "chersalon";
diffuseMap[0] = "vehicles/bentleybentayga/1.png";
    diffuseMap[1] = "vehicles/bentleybentayga/1.png";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(Wheel1A)
{
mapTo = "Wheel1A";
materialTag0 = "Wheel1A"; materialTag1 = "vehicle";
colorMap[0] = "vehicles/bmwm2/Wheel1A_diff.png";
pixelSpecular[0] = "1";
doubleSided = "1";
diffuseColor[0] = "0.988235 0.996078 0.988235 0.396";
instanceDiffuse[0] = 0;
dynamicCubemap = false;
};

singleton Material(ski_box_fen)
{
    mapTo = "ski_box_fen";
    diffuseMap[0] = "vehicles/panamera/1.png";
    specularMap[0] = "vehicles/panamera/1.png";
    diffuseMap[1] = "vehicles/panamera/1.png";
    specularMap[1] = "vehicles/panamera/1.png";
    diffuseColor[0] = "0.8 0.8 0.8 1";
    diffuseColor[1] = "0.9 0.9 0.9 0.6";
    specularPower[0] = "16";
    specularPower[1] = "16";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "1";
    alphaRef = "0";
    beamngDiffuseColorSlot = 1;
    doubleSided = "1";
    dynamicCubemap = true;
};

singleton Material(lightper2)
{
   mapTo = "lightper2";
   specular[0] = "0.996078491 0.996078491 0.996078491 1";
   specular[1] = "0.996078491 0.996078491 0.996078491 1";
   colorMap[0] = "vehicles/panamera/1.png";
   glow[0] = "1";
   glow[1] = "1";
   emissive[0] = "1";
   emissive[1] = "1";
   pixelSpecular[0] = "1";
   pixelSpecular[1] = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(white)
{
   mapTo = "white";
   specular[0] = "0.996078491 0.996078491 0.996078491 1";
   specular[1] = "0.996078491 0.996078491 0.996078491 1";
   colorMap[0] = "vehicles/panamera/1.png";
   glow[0] = "3";
   glow[1] = "3";
   emissive[0] = "5";
   emissive[1] = "5";
   pixelSpecular[0] = "1";
   pixelSpecular[1] = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(faraz)
{
   mapTo = "faraz";
    diffuseMap[0] = "vehicles/panamera/6.png";
    diffuseMap[1] = "vehicles/panamera/6.png";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(svetzad)
{
    mapTo = "svetzad";
    diffuseMap[0] = "vehicles/panamera/3.png";
    diffuseMap[1] = "vehicles/panamera/3.png";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(red)
{
   mapTo = "red";
   specular[0] = "0.996078491 0.996078491 0.996078491 1";
   specular[1] = "0.996078491 0.996078491 0.996078491 1";
   colorMap[0] = "vehicles/panamera/red.png";
   diffuseMap[0] = "vehicles/panamera/red.png";
   diffuseMap[1] = "vehicles/panamera/red.png";
   glow[0] = "3";
   glow[1] = "3";
   emissive[0] = "5";
   emissive[1] = "5";
   pixelSpecular[0] = "1";
   pixelSpecular[1] = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(signal)
{
    mapTo = "signal";
    diffuseMap[0] = "vehicles/panamera/6.png";
    diffuseMap[1] = "vehicles/panamera/6.png";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(orange)
{
   mapTo = "orange";
   specular[0] = "0.996078491 0.996078491 0.996078491 1";
   specular[1] = "0.996078491 0.996078491 0.996078491 1";
   colorMap[0] = "vehicles/panamera/orange.png";
   diffuseMap[0] = "vehicles/panamera/orange.png";
   diffuseMap[1] = "vehicles/panamera/orange.png";
   glow[0] = "3";
   glow[1] = "3";
   emissive[0] = "5";
   emissive[1] = "5";
   pixelSpecular[0] = "1";
   pixelSpecular[1] = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(screen)
{
    mapTo = "screen";
    diffuseMap[0] = "@etk800_screen";
    reflectivityMap[0] = "vehicles/panamera/BMWM5F10_screen_s.dds";
    diffuseColor[0] = "1 1 1 1";
    specularPower[0] = "32";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    cubemap = "global_cubemap_metalblurred";
    emissive[0] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(parking)
{
    mapTo = "parking";
    diffuseMap[0] = "vehicles/panamera/6.png";
    diffuseMap[1] = "vehicles/panamera/6.png";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(steer)
{
    mapTo = "steer";
    diffuseMap[0] = "vehicles/panamera/koja.tga";
    diffuseMap[1] = "vehicles/panamera/koja.tga";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(leatherperf)
{
    mapTo = "leatherperf";
    diffuseMap[0] = "vehicles/panamera/koja.tga";
    diffuseMap[1] = "vehicles/panamera/koja.tga";
    diffuseColor[0] = "0.8 0.8 0.8 1";
    diffuseColor[1] = "0.9 0.9 0.9 0.6";
    specularPower[0] = "0";
    specularPower[1] = "0";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "1";
    alphaRef = "0";
    beamngDiffuseColorSlot = 1;
    doubleSided = "1";
    dynamicCubemap = true;
};

singleton Material(remen)
{
    mapTo = "remen";
    diffuseMap[0] = "vehicles/panamera/cinture.tga";
    diffuseMap[1] = "vehicles/panamera/cinture.tga";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(verx)
{
    mapTo = "verx";
    diffuseMap[0] = "vehicles/panamera/leather_perf2.tga";
    diffuseMap[1] = "vehicles/panamera/leather_perf2.tga";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(disk)
{
    mapTo = "disk";
    diffuseMap[0] = "vehicles/panamera/1.dds";
    diffuseMap[1] = "vehicles/panamera/1.dds";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(gray)
{
    mapTo = "gray";
    diffuseMap[0] = "vehicles/panamera/koja.tga";
    diffuseMap[1] = "vehicles/panamera/koja.tga";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(doorzvuk)
{
    mapTo = "doorzvuk";
    diffuseMap[0] = "vehicles/panamera/zvuk.png";
    diffuseMap[1] = "vehicles/panamera/zvuk.png";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(pol)
{
    mapTo = "pol";
    diffuseMap[0] = "vehicles/panamera/carpet_black.tga";
    diffuseMap[1] = "vehicles/panamera/carpet_black.tga";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(logodisk)
{
    mapTo = "logodisk";
    diffuseMap[0] = "vehicles/panamera/logo.jpg";
    diffuseMap[1] = "vehicles/panamera/logo.jpg";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(logorul)
{
    mapTo = "logorul";
    diffuseMap[0] = "vehicles/panamera/logo1.jpg";
    diffuseMap[1] = "vehicles/panamera/logo1.jpg";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(logokap)
{
    mapTo = "logokap";
    diffuseMap[0] = "vehicles/panamera/logo1.jpg";
    diffuseMap[1] = "vehicles/panamera/logo1.jpg";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(sery)
{
    mapTo = "sery";
    diffuseMap[0] = "vehicles/panamera/4.png";
    diffuseMap[1] = "vehicles/panamera/4.png";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material("etk800.skin.polizei")
{
    mapTo = "etk800.skin.polizei";
    overlayMap[2] = "vehicles/panamera/supreme.png";
    diffuseMap[2] = "vehicles/panamera/KG_c.dds";
    specularMap[2] = "vehicles/panamera/KG_s.dds";
    normalMap[2] = "vehicles/panamera/KG_n.dds";
    diffuseMap[1] = "vehicles/panamera/KG_d.dds";
    specularMap[1] = "vehicles/panamera/KG_s.dds";
    normalMap[1] = "vehicles/panamera/KG_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/panamera/KG_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    specularPower[2] = "128";
    pixelSpecular[2] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";

};

singleton Material(plog)
{
    mapTo = "plog";
    diffuseMap[0] = "vehicles/panamera/plog.jpg";
    diffuseMap[1] = "vehicles/panamera/plog.jpg";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(polosa)
{
    mapTo = "polosa";
    diffuseMap[0] = "vehicles/panamera/1.png";
    diffuseMap[1] = "vehicles/panamera/1.png";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(screen2)
{
    mapTo = "screen2";
    diffuseMap[0] = "@etk800_screen";
    reflectivityMap[0] = "vehicles/panamera/BMWM5F10_screen_s.dds";
    diffuseColor[0] = "1 1 1 1";
    specularPower[0] = "32";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    cubemap = "global_cubemap_metalblurred";
    emissive[0] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(kryshka)
{
    mapTo = "kryshka";
    diffuseMap[0] = "vehicles/panamera/5.png";
    diffuseMap[1] = "vehicles/panamera/5.png";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(dispsp)
{
    mapTo = "dispsp";
    diffuseMap[0] = "vehicles/panamera/dispsp.jpg";
    diffuseMap[1] = "vehicles/panamera/dispsp.jpg";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(etk800_windshield_dmg)
{
    mapTo = "etk800_windshield_dmg";
    reflectivityMap[0] = "vehicles/common/glass_base.dds";
    diffuseMap[0] = "vehicles/panamera/25.png";
    specularMap[0] = "vehicles/panamera/25.png";
    specularPower[0] = "32";
    diffuseColor[0] = "1.5 1.5 1.5 1";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(navi)
{
    mapTo = "navi";
    diffuseMap[0] = "vehicles/panamera/navi.jpg";
    diffuseMap[1] = "vehicles/panamera/navi.jpg";
    diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};